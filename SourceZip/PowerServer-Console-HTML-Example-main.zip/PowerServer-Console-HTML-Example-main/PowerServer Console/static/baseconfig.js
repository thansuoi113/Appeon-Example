export default{
  baseUrl:"https://psdemo.appeon.com:9001/api.sales",
  setBaseUrl(url){
    this.baseUrl = url;
  }
}
