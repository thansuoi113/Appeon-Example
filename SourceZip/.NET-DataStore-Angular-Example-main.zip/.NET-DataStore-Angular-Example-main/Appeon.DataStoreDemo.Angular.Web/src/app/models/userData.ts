export class UserData {
  username: string;

  constructor() {

  }
}
