
export class ProductCategoryData {
  constructor (
    public name: string,
    public type: 'bar',
    public data: number[]
  ){}
}
