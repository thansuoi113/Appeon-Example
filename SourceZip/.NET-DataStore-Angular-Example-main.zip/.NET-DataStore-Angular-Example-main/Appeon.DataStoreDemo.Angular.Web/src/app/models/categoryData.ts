export class CategoryData {
  constructor(public name: string, public value: number) {}
}
