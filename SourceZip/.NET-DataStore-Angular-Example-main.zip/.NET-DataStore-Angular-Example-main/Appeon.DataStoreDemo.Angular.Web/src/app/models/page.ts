
export class Page<T>{
  public pageIndex: number;
  public totalItems: number;
  public pageSize: number;
  public items: T;
}
