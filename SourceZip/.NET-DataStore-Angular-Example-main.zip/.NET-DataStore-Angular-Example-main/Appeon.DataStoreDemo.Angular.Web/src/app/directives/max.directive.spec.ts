import { MaxDirective } from './max.directive';

describe('MaxDirective', () => {
  it('should create an instance', () => {
    const directive = new MaxDirective();
    expect(directive).toBeTruthy();
  });
});
