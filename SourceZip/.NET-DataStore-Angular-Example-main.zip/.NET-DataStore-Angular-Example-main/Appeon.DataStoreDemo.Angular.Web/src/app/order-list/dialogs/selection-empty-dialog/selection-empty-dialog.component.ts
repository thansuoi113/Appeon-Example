import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selection-empty-dialog',
  templateUrl: './selection-empty-dialog.component.html',
  styleUrls: ['./selection-empty-dialog.component.css']
})
export class SelectionEmptyDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
