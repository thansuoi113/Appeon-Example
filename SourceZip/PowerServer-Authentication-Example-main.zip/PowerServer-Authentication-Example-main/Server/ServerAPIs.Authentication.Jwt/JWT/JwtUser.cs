﻿using ServerAPIs.Authentication.Common;

namespace ServerAPIs.Authentication.Jwt
{
    public class JwtUser : User
    {

    }
}
