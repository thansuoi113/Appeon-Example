# PowerBuilder-RibbonBar-Example

This example shows you how to replace an application menu with a RibbonBar using the 2019 R3 version. For more information, check the tutorial [How to Replace an Application Menu with a RibbonBar](https://github.com/Appeon/PowerBuilder-RibbonBar-Example/blob/master/How%20to%20Replace%20an%20Application%20Menu%20with%20a%20RibbonBar.md).
