﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Appeon.MvcModelMapperDemo.Pages
{
    public class PrivacyModel : PageModel
    {
        public void OnGetAsync()
        {

        }

    }
}