﻿namespace Appeon.DataStoreDemo.SqlServer.Services
{
    public interface IAddressService : IServiceBase
    {

    }

}
