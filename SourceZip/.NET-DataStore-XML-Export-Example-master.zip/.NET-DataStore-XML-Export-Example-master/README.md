# .NET-DataStore-XML-Export-Example

Run this sample project in PowerBuilder 2021 to experience the process of exporting .NET DataStore data to XML with or without template. For more information, check the tutorial [Using Export Templates for XML or JSON Export](https://github.com/Appeon/.NET-DataStore-XML-Export-Example/blob/master/Using_Export_Templates_for_XML_or_JSON_Export.md).
