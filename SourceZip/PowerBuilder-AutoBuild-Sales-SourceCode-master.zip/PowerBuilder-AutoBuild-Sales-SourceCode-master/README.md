# PowerBuilder-AutoBuild-Sales-SourceCode
This GitHub repository contains the source code of the Sales Example object level (not including PBLs) which is used for examples that demonstrate the PBAutoBuild feature. PBAutoBuild can download and merge the object source code into PBLs.
